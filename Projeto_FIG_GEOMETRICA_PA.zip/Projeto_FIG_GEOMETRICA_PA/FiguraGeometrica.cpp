#include "FiguraGeometrica.h"

FiguraGeometrica::FiguraGeometrica(){

}

FiguraGeometrica::~FiguraGeometrica(){
   
}